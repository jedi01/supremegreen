# Icons8 Line Awesome

There is available a live [preview](https://icons8.com/line-awesome) of the icon set.


## Good Boy License

We’ve released the icon pack either under MIT or the [Good Boy License](https://icons8.com/good-boy-license/). We invented it. Please do _whatever your mom would approve of:_
* Download
* Change
* Fork

No tattoos!


### Installing

```shell
npm install icons8/line-awesome
```

## Credits

Based on the [Windows 10 icon pack](https://icons8.com/download-huge-windows8-set/). The original ones contains 4,500 icons and is too heavy for a single font. 

## Questions or Ideas?

If you have any questions or ideas about icons, [please feel free to contact us](https://github.com/icons8/line-awesome/issues).
